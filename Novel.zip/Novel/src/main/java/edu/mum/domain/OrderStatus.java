package edu.mum.domain;

public enum OrderStatus {
	ORDERED, COMFIRMED, PREPARING, WAITING, DELVERED;
}
