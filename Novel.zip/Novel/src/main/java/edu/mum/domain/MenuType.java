package edu.mum.domain;

public enum MenuType {
	BREAKFAST, LUNCH, DINNER, BRUNCH;
}
