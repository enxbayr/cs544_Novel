package edu.mum.domain;

public enum UserRole {
	STUDENT, FACULTY, STAFF, ADMIN;
}
